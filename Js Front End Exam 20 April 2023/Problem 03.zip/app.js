function attachEvents() {
  BASE_URL = `http://localhost:3030/jsonstore/tasks/`;
  let courseName = document.getElementById(`course-name`);
  let courseType = document.getElementById(`course-type`);
  let courseDesc = document.getElementById(`description`);
  let teacherName = document.getElementById(`teacher-name`);
  let addBtn = document.getElementById(`add-course`);
  let editCourseMainBtn = document.getElementById(`edit-course`);
  let loadBtn = document.getElementById(`load-course`);
  let courseList = document.getElementById(`list`);

  loadBtn.addEventListener(`click`, loadCoursesEvent);
  addBtn.addEventListener(`click`, addCourseEvent);

  function loadCoursesEvent(event) {
    event.preventDefault();

    courseList.innerHTML = ``;

    fetch(BASE_URL)
      .then((response) => response.json())
      .then((data) => {
        for (const obj of Object.values(data)) {
          let parentContainer = createElement(`div`, courseList, null, [
            `container`,
          ]);
          parentContainer.id = obj._id;
          createElement(`h2`, parentContainer, `${obj.title}`);
          createElement(`h3`, parentContainer, `${obj.teacher}`);
          createElement(`h3`, parentContainer, `${obj.type}`);
          createElement(`h4`, parentContainer, `${obj.description}`);
          let editBtn = createElement(
            `button`,
            parentContainer,
            `Edit Course`,
            [`edit-btn`]
          );
          let finishBtn = createElement(
            `button`,
            parentContainer,
            `Finish Course`,
            [`finish-btn`]
          );

          editBtn.addEventListener(`click`, editInnerEvent);
          finishBtn.addEventListener(`click`, finishCourseEvent);
        }
      });
  }

  function addCourseEvent(event) {
    event.preventDefault();

    let newCourse = courseName.value;
    let newType = courseType.value;
    let newDesc = courseDesc.value;
    let newTeacher = teacherName.value;

    if (
      courseName.value == `` ||
      courseType.value == `` ||
      courseDesc.value == `` ||
      teacherName.value == ``
    ) {
      return;
    }

    if (
      courseType.value != `Long` &&
      courseType.value != `Medium` &&
      courseType.value != `Short`
    ) {
      return;
    }

    fetch(`${BASE_URL}`, {
      method: `POST`,
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        title: newCourse,
        type: newType,
        description: newDesc,
        teacher: newTeacher,
      }),
    }).then(() => loadCoursesEvent(event));
    courseName.value = ``;
    courseType.value = ``;
    courseDesc.value = ``;
    teacherName.value = ``;
  }

  function editInnerEvent(event) {
    event.preventDefault();
    let parent = this.parentNode;
    addBtn.disabled = true;
    editCourseMainBtn.disabled = false;
    let [title, teacher, type, description, _editBtn, _finishBtn] = Array.from(
      parent.children
    );
    courseName.value = title.innerHTML;
    teacherName.value = teacher.innerHTML;
    courseType.value = type.innerHTML;
    courseDesc.value = description.innerHTML;
    parent.remove();

    editCourseMainBtn.addEventListener(`click`, finalEdit);

    function finalEdit(event) {
      event.preventDefault();

      let id = parent.id;
      let editedCourse = courseName.value;
      let editedType = courseType.value;
      let editedDesc = courseDesc.value;
      let editedTeacher = teacherName.value;

      if (
        editedCourse == `` ||
        editedType == `` ||
        editedDesc == `` ||
        editedTeacher == ``
      ) {
        return;
      }

      if (
        editedType != `Long` &&
        editedType != `Medium` &&
        editedType != `Short`
      ) {
        return;
      }

      fetch(`${BASE_URL}${id}`, {
        method: `PUT`,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: editedCourse,
          type: editedType,
          description: editedDesc,
          teacher: editedTeacher,
        }),
      }).then(() => {
        loadCoursesEvent(event);
        addBtn.disabled = false;
        editCourseMainBtn.disabled = true;
        courseName.value = ``;
        courseType.value = ``;
        courseDesc.value = ``;
        teacherName.value = ``;
      });
    }
  }

  function finishCourseEvent(event){
    event.preventDefault();
    let parent = this.parentNode;
    let id = parent.id;
    
    fetch(`${BASE_URL}${id}`, {
      method: `DELETE`
    }).then(() => parent.remove());
  }

  function createElement(
    type,
    parentNode,
    content,
    classes,
    id,
    attributes,
    useInnerHtml
  ) {
    const htmlElement = document.createElement(type);

    if (content && useInnerHtml) {
      htmlElement.innerHTML = content;
    } else {
      if (content && type !== "input") {
        htmlElement.textContent = content;
      }

      if (content && type === "input") {
        htmlElement.value = content;
      }
    }

    if (classes && classes.length > 0) {
      htmlElement.classList.add(...classes);
    }

    if (id) {
      htmlElement.id = id;
    }

    // { src: 'link', href: 'http' }
    if (attributes) {
      for (const key in attributes) {
        htmlElement.setAttribute(key, attributes[key]);
      }
    }

    if (parentNode) {
      parentNode.appendChild(htmlElement);
    }

    return htmlElement;
  }
}

attachEvents();
